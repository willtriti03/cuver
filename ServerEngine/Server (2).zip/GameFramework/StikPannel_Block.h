#ifndef _STIKPANNEL_H_
#define _STIKPANNEL_H_

#include "ISceneNode.h"
#include "Sprite.h"

#endif