#pragma once
#ifndef _DELETEBLOCK_H_
#define _DELETEBLOCK_H_

class DeleteBlock
{
public:
	DeleteBlock();
	~DeleteBlock();
};

#endif

