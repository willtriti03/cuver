#pragma once
class SetPos
{
public:
	SetPos();
	virtual ~SetPos();
};

