#ifndef _MIX_H_
#define _MIX_H_
#include <string>
class Mix{
private:
	void Change(std::string str);

};
#endif