#ifndef _FUNCTION_H_
#define _FUNCTION_H_

#include <windows.h>

LRESULT WINAPI MsgProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);

#endif