#ifndef _SAVE_H_
#define _SAVE_H_

#include <iostream>
#include "ISceneNode.h"

class Save :public ISceneNode{
private:



public:



};
#endif