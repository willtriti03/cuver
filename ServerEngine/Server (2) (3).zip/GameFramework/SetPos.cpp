#include "SetPos.h"


SetPos::SetPos()
{
}


SetPos::~SetPos()
{
}
