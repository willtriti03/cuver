#ifndef _PATHMGR_H_
#define _PATHMGR_H_

#include <string>
#include <iostream>
#include <fstream>
#define PathMgr PathManager::GetInstance()

class PathManager{
public:
	PathManager();
	~PathManager();

	static PathManager* GetInstance();

	std::string str,projectName,savePath,test;
	std::string cursor,splash;
	

};
#endif