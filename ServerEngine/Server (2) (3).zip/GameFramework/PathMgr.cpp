#include "PathMgr.h"

#define First "Theme/"
using namespace std;
PathManager* PathManager::GetInstance(){
	static PathManager Instance;
	return &Instance;
}
PathManager::PathManager(){
	std::ifstream readSet("settings/setting.txt");
	readSet >> str>>savePath>>projectName;
	test	=First+ str + "/make.png";
	cursor	=First+ str + "/cursor/cursor.png";
	splash	=First+ str + "/Splash/Logo3.png";

}
PathManager::~PathManager(){
}