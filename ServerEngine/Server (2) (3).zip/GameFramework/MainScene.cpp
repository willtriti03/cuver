#include"MainScene.h"
#include <conio.h>
#include "Wheel.h"
#include "BroadCast.h"
#include "InputManager.h"
#include "DebugFile.h"
using namespace std;
MainScene::MainScene(){
	m_pCursor = new MouseCusor();
	for (int i = 0; i < 5; ++i){

		Block *m_pBlock = new Block();
		m_pBlock->AddBlockImage(PathMgr->test);
		pushScene(m_pBlock, false);
		m_pBlock->setPos(200 * i, 0);
		BroadMgr->UserBlock.push_back(m_pBlock);

	}
	m_pEdit = new EditText(300, 200);
	pushScene(m_pEdit, false);
	(BroadMgr->CppFileName).push_back("main.cpp");
	(BroadMgr->HeaderFileName).push_back("main.h");
	BroadMgr->mouseMode = 1;
	//	Debugs->Debug();


}

MainScene::~MainScene(){

}

void MainScene::update(float eTime){
	ISceneNode::update(eTime);
	if (!BroadMgr->pause)
		for (std::list<Block *>::iterator it = BroadMgr->UserBlock.begin(); it != BroadMgr->UserBlock.end();){
			if (*it != nullptr)
				(*it)->update(eTime);
			++it;
			if (it == BroadMgr->UserBlock.end())
				break;
		}
	m_pEdit->update(eTime);
	m_pCursor->update(eTime);
	if (InputMgr->keyState('S')==2){
		BroadMgr->mouseMode = 2;
	}
	if (InputMgr->keyState('D') == 2){
		BroadMgr->mouseMode = 1;
	}
	//if (InputMgr->keyPress()!=256)
	//printf("%d\n", InputMgr->keyPress());
}

void MainScene::render(){
	ISceneNode::render();
	if (!BroadMgr->pause)
		for (std::list<Block *>::iterator it = BroadMgr->UserBlock.begin(); it != BroadMgr->UserBlock.end();){
			if (*it != nullptr)
				(*it)->render();
			++it;
			if (it == BroadMgr->UserBlock.end())
				break;
		}
	m_pEdit->render();
	m_pCursor->render();

}
