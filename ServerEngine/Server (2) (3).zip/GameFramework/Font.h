#ifndef _FONT_H_
#define _FONT_H_
 
#include "ISceneNode.h"
#include "Application.h"
#include "SpriteManager.h"
#include <string>
class CFont :public ISceneNode{
private:
	LPD3DXFONT font;
public:
	char *string;
	char *fontname;
	DWORD color;
	int len;

	CFont(int bufferSize, UINT size, char* fontname = "���� ����");
	~CFont();

	void render();
	void update(float eTime);

	void SetText(LPCSTR fmt, ...);
	void setString(char string[], bool autosize = true);
	void setString(std::string string, bool autosize = true);
	void SetColor(D3DXCOLOR color) { this->color = color; };
};

#endif