#include "ToolBar.h"

ToolBar::ToolBar(){
	std::string tmp;
	char sz_buf[_MAX_PATH];
	
	m_pToolBar_BG->Create("Images/ToolBar/ToolBar_BG.png");
	m_pToolBar_BG->setPosition(D3DXVECTOR2(0, 0));
	pushScene(m_pToolBar_BG, false);

	for (int i = 0; i < BTN_CNT; ++i){
		tmp=sprintf_s(sz_buf, "Images/ToolBar/Button/UserBtn_%d_Usual.png",i);
		m_pUserBtn[i]->AddUsualButtonImage(tmp);

		tmp = sprintf_s(sz_buf, "Images/ToolBar/Button/UserBtn_%d_On.png", i);
		m_pUserBtn[i]->AddOnButtonImage(tmp);

		
		if (i % 2 == 0){
			m_pUserBtn[i]->setPosition(D3DXVECTOR2(BTN_RIGHT_DISTENCE, 150+BTN_BOTTOM_DISTENCE*i+BTN_HEIGHT*i));
		}
		else {
			m_pUserBtn[i]->setPosition(D3DXVECTOR2(BTN_RIGHT_DISTENCE*2+BTN_WIDTH, 150 + BTN_BOTTOM_DISTENCE*i + BTN_HEIGHT*i));
		}

		pushScene(m_pUserBtn[i],false);
	
	
	}
}

ToolBar::~ToolBar(){
}

void ToolBar::update(float eTime){
}

void ToolBar::render(){
}
