#ifndef _PLAYBOARD_H_
#define _PLAYBOARD_H_

#include "ISceneNode.h"
class PlayBoard :public ISceneNode{
private:
public:
	PlayBoard();
	~PlayBoard();

	void update(float eTime);
	void render();

};
#endif
