#include "DeleteBlock.h"


DeleteBlock::DeleteBlock()
{
}


DeleteBlock::~DeleteBlock()
{
}
