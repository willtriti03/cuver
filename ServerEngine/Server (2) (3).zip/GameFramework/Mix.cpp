#include "Mix.h"
void Mix::Change(std::string str){

	
}