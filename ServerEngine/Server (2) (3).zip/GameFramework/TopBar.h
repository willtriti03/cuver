#ifndef _TOPBAR_H_
#define _TOPBAR_H_

#include "ISceneNode.h"
class TopBar :public ISceneNode{
private:
public:
	TopBar();
	~TopBar();

	void update(float eTime);
	void render();

};
#endif
