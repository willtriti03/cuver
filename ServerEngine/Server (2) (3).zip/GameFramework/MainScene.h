#ifndef _MAINSCENE_H_
#define _MAINSCENE_H_

#include"ISceneNode.h"
#include "Sprite.h"
#include "Font.h"
#include "Block.h"
#include "PathMgr.h"
#include "MouseCusor.h"
#include "EditText.h"
#include <string>
#include <list>

class MainScene : public ISceneNode{
private:
public:
	EditText *m_pEdit;
	MouseCusor *m_pCursor;

public:

	MainScene();
	~MainScene();

	void render();
	void update(float eTime);

};

#endif