#ifndef _TOOLBAR_H_
#define _TOOLBAR_H_

////////////////Btn Img Infom///////////////////

#define BTN_WIDTH 40
#define BTN_HEIGHT 40
#define BTN_RIGHT_DISTENCE 20
#define BTN_BOTTOM_DISTENCE 20

#define BTN_CNT 10

////////////////////////////////////////////////

#include "ISceneNode.h"
#include "Sprite.h"
#include "GUIButton.h"

class ToolBar :public ISceneNode{
private:
	Sprite		*m_pToolBar_BG;
	GUIButton	*m_pUserBtn[BTN_CNT];
public:
	ToolBar();
	~ToolBar();

	/////////////////////UserBtn FucTion//////////////////////////


	//////////////////////////////////////////////////////////////

	void update(float eTime);
	void render();
};

#endif